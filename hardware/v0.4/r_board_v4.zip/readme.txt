Note:  Excellon drill file resolution at 5 digits
